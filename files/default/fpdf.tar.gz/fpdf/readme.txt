http://shikabo.ddo.jp/?cat=72
http://makisuke.seesaa.net/article/49102768.html