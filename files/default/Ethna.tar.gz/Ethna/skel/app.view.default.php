<?php
/**
 *  Index.php
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id: app.view.default.php 387 2006-11-06 14:31:24Z cocoitiban $
 */

/**
 *  index�ӥ塼�μ���
 *
 *  @author     {$author}
 *  @access     public
 *  @package    {$project_id}
 */
class {$project_id}_View_Index extends {$project_id}_ViewClass
{
    /**
     *  ����������
     *
     *  @access public
     */
    function preforward()
    {
    }
}
?>
