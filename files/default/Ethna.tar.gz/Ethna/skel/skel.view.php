<?php
/**
 *  {$view_path}
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id: skel.view.php 387 2006-11-06 14:31:24Z cocoitiban $
 */

/**
 *  {$forward_name}�ӥ塼�μ���
 *
 *  @author     {$author}
 *  @access     public
 *  @package    {$project_id}
 */
class {$view_class} extends {$project_id}_ViewClass
{
    /**
     *  ����������
     *
     *  @access public
     */
    function preforward()
    {
    }
}
?>
