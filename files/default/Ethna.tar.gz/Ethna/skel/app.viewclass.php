<?php
// vim: foldmethod=marker
/**
 *  {$project_id}_ViewClass.php
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id: app.viewclass.php 323 2006-08-22 15:52:26Z fujimoto $
 */

// {{{ {$project_id}_ViewClass
/**
 *  view���饹
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @access     public
 */
class {$project_id}_ViewClass extends Ethna_ViewClass
{
    /**
     *  �����ͤ����ꤹ��
     *
     *  @access protected
     *  @param  object  {$project_id}_Renderer  �����饪�֥�������
     */
    function _setDefault(&$renderer)
    {
    }
}
// }}}
?>
