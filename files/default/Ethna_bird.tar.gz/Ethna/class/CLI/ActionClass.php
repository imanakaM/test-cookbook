<?php
// vim: foldmethod=marker
/**
 *  ActionClass.php
 *
 *  @author     Masaki Fujimoto <fujimoto@php.net>
 *  @license    http://www.opensource.org/licenses/bsd-license.php The BSD License
 *  @package    Ethna
 *  @version    $Id: b99d15bbae332fc63f336f548679f8cfe375d06d $
 */

// {{{ Ethna_CLI_ActionClass
/**
 *  コマンドラインaction実行クラス
 *
 *  @author     Masaki Fujimoto <fujimoto@php.net>
 *  @access     public
 *  @package    Ethna
 *  @obsolete
 */
class Ethna_CLI_ActionClass extends Ethna_ActionClass
{
    /**
     *  action処理
     *
     *  @access public
     */
    public function perform()
    {
        parent::perform();
        $_SERVER['REMOTE_ADDR'] = "0.0.0.0";
        $_SERVER['HTTP_USER_AGENT'] = "";
    }
}
// }}}
