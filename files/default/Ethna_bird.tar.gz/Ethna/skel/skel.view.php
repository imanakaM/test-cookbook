<?php
/**
 *  {$view_path}
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id: 6a152841e30d3c762e3a60c8ac0899a72c0641d2 $
 */

/**
 *  {$forward_name} view implementation.
 *
 *  @author     {$author}
 *  @access     public
 *  @package    {$project_id}
 */
class {$view_class} extends {$project_id}_ViewClass
{
    /** @var boolean  layout template use flag   */
    var $use_layout = true;

    /**
     *  preprocess before forwarding.
     *
     *  @access public
     */
    function preforward()
    {
    }
}

