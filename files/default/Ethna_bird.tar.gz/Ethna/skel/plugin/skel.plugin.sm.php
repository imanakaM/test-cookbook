<?php
// vim: foldmethod=marker
/**
 *  {$plugin_name} Smarty modifier Plugin
 *
 *  @author     your name <yourname@example.com>
 *  @license    http://www.opensource.org/licenses/bsd-license.php The BSD License
 *  @package    Ethna_Plugin
 *  @version    $Id: 1555331362a21dddc8a46838e5495694ced492da $
 */

function smarty_modifier_{$plugin_name}($string)
{
}
