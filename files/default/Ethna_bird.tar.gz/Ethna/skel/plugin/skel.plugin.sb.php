<?php
// vim: foldmethod=marker
/**
 *  {$plugin_name} Smarty block Plugin
 *
 *  @author     your name <yourname@example.com>
 *  @license    http://www.opensource.org/licenses/bsd-license.php The BSD License
 *  @package    Ethna_Plugin
 *  @version    $Id: ada61d1958661ac41a6209b36fdf78b6096895c6 $
 */

function smarty_block_{$plugin_name}($params, $content, &$smarty, &$repeat)
{
}
