<?php
/**
 *  {$project_id}_Error.php
 *
 *  @package   {$project_id}
 *
 *  $Id: 74177f6a3edb02db5e7a817f570f56ef77e7f690 $
 */

/*--- Application Error Definition ---*/
/*
 *  TODO: Write application error definition here.
 *        Error codes 255 and below are reserved 
 *        by Ethna, so use over 256 value for error code.
 *
 *  Example:
 *  define('E_LOGIN_INVALID', 256);
 */
